<?php
class MyClass {
	
}