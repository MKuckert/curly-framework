<?php
class MySecondClass {
	
}