<?php

require_once "CurlyX/Archive/Parser/Base/Algorithm/Interface.php";

/**
 * CurlyX_Archive_Parser_Zip
 *
 * Diese Archiv-Parser-Klasse kapselt die ZipArchive-Klasse von PHP.
 *
 * @author Martin Kuckert
 * @copyright Copyright &copy; 2008 Martin Kuckert
 * @license New BSD License
 * @package CurlyX.Archive.Parser
 * @since 1.0 - 11.12.2008
 * @version 1.0
 */
class CurlyX_Archive_Parser_Zip implements CurlyX_Archive_Parser_Interface {
	
}
